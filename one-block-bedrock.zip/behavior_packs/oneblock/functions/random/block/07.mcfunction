scoreboard players random @s random 1 70
execute as @s[scores={random=1}] run setblock 0 63 0 grass
execute as @s[scores={random=2}] run setblock 0 63 0 cobblestone
execute as @s[scores={random=3}] run setblock 0 63 0 stone
execute as @s[scores={random=4}] run setblock 0 63 0 mossy_cobblestone
execute as @s[scores={random=5}] run setblock 0 63 0 sand
execute as @s[scores={random=6}] run setblock 0 63 0 blackstone
execute as @s[scores={random=7}] run setblock 0 63 0 netherrack
execute as @s[scores={random=8}] run setblock 0 63 0 sand["sand_type"="red"]
execute as @s[scores={random=9}] run setblock 0 63 0 red_sandstone
execute as @s[scores={random=10}] run setblock 0 63 0 prismarine
execute as @s[scores={random=11}] run setblock 0 63 0 jungle_log
execute as @s[scores={random=12}] run setblock 0 63 0 iron_ore
execute as @s[scores={random=13}] run setblock 0 63 0 coal_ore
execute as @s[scores={random=14}] run setblock 0 63 0 gravel
execute as @s[scores={random=15}] run setblock 0 63 0 nether_brick
execute as @s[scores={random=16}] run setblock 0 63 0 soul_sand
execute as @s[scores={random=17}] run setblock 0 63 0 prismarine["prismarine_block_type"="bricks"]
execute as @s[scores={random=18}] run setblock 0 63 0 stone["stone_type"="diorite"]
execute as @s[scores={random=19}] run setblock 0 63 0 redstone_ore
execute as @s[scores={random=20}] run setblock 0 63 0 oak_log
execute as @s[scores={random=21}] run setblock 0 63 0 red_nether_brick
execute as @s[scores={random=22}] run setblock 0 63 0 basalt
execute as @s[scores={random=23}] run setblock 0 63 0 hardened_clay
execute as @s[scores={random=24}] run setblock 0 63 0 sandstone
execute as @s[scores={random=25}] run setblock 0 63 0 prismarine["prismarine_block_type"="dark"]
execute as @s[scores={random=26}] run setblock 0 63 0 snow
execute as @s[scores={random=27}] run setblock 0 63 0 stone["stone_type"="andesite"]
execute as @s[scores={random=28}] run setblock 0 63 0 stone["stone_type"="granite"]
execute as @s[scores={random=29}] run setblock 0 63 0 dirt
execute as @s[scores={random=30}] run setblock 0 63 0 clay
execute as @s[scores={random=31}] run setblock 0 63 0 crimson_nylium
execute as @s[scores={random=32}] run setblock 0 63 0 warped_nylium
execute as @s[scores={random=33}] run setblock 0 63 0 magma
execute as @s[scores={random=34}] run setblock 0 63 0 stained_hardened_clay ["color"="red"]
execute as @s[scores={random=35}] run setblock 0 63 0 stained_hardened_clay ["color"="orange"]
execute as @s[scores={random=36}] run setblock 0 63 0 stained_hardened_clay ["color"="yellow"]
execute as @s[scores={random=37}] run setblock 0 63 0 stained_hardened_clay ["color"="brown"]
execute as @s[scores={random=38}] run setblock 0 63 0 acacia_log
execute as @s[scores={random=39}] run setblock 0 63 0 spruce_log
execute as @s[scores={random=40}] run setblock 0 63 0 soul_soil
execute as @s[scores={random=41}] run setblock 0 63 0 glowstone
execute as @s[scores={random=42}] run setblock 0 63 0 dark_oak_log
execute as @s[scores={random=43}] run setblock 0 63 0 birch_log
execute as @s[scores={random=44}] run setblock 0 63 0 quartz_ore
execute as @s[scores={random=45}] run setblock 0 63 0 nether_wart_block
execute as @s[scores={random=46}] run setblock 0 63 0 warped_wart_block
execute as @s[scores={random=47}] run setblock 0 63 0 gilded_blackstone
execute as @s[scores={random=48}] run setblock 0 63 0 shroomlight
execute as @s[scores={random=49}] run setblock 0 63 0 stained_hardened_clay ["color"="silver"]
execute as @s[scores={random=50}] run setblock 0 63 0 stained_hardened_clay ["color"="white"]
execute as @s[scores={random=51}] run setblock 0 63 0 gold_ore
execute as @s[scores={random=52}] run setblock 0 63 0 packed_ice
execute as @s[scores={random=53}] run setblock 0 63 0 nether_gold_ore
execute as @s[scores={random=54}] run setblock 0 63 0 sea_lantern
execute as @s[scores={random=55}] run setblock 0 63 0 emerald_ore
execute as @s[scores={random=56}] run setblock 0 63 0 coral_block["coral_color"="pink"]
execute as @s[scores={random=57}] run setblock 0 63 0 coral_block["coral_color"="yellow"]
execute as @s[scores={random=58}] run setblock 0 63 0 podzol
execute as @s[scores={random=59}] run setblock 0 63 0 sponge
execute as @s[scores={random=60}] run setblock 0 63 0 obsidian
execute as @s[scores={random=61}] run setblock 0 63 0 coral_block["coral_color"="red"]
execute as @s[scores={random=62}] run setblock 0 63 0 coral_block["coral_color"="blue"]
execute as @s[scores={random=63}] run setblock 0 63 0 coral_block["coral_color"="purple"]
execute as @s[scores={random=64}] run setblock 0 63 0 melon_block
execute as @s[scores={random=65}] run setblock 0 63 0 diamond_ore
execute as @s[scores={random=66}] run setblock 0 63 0 lapis_ore
execute as @s[scores={random=67}] run setblock 0 63 0 pumpkin
execute as @s[scores={random=68}] run setblock 0 63 0 birch_log
execute as @s[scores={random=69}] run setblock 0 63 0 ancient_debris
execute as @s[scores={random=70}] run setblock 0 63 0 crying_obsidian

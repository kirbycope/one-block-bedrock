tp @s 0.5 60.5 0.5
execute as @s[scores={ija-a4-end-portal-effects=1..}] run function effects/end-portal
execute if block 0 60 0 farmland run setblock 0 60 0 dirt
execute unless block ~ ~ ~ chest run kill @e[type=oneblock:label_entity,tag=ija-a4-chest]
function infinite-block/show-particles

execute if block 0 60 0 air run tag @s add ija-a4-mined
execute if block 0 60 0 fire run tag @s add ija-a4-mined
execute if block 0 60 0 water run tag @s add ija-a4-mined
execute if block 0 60 0 flowing_water run tag @s add ija-a4-mined

execute as @s[scores={ija-a4-upgrade-seconds-left=1..}] run function infinite-block/upgrade/manager

execute as @s[tag=ija-a4-mined] run fill 0 60 0 0 60 0 barrier replace air
execute as @s[tag=ija-a4-mined] run fill 0 60 0 0 60 0 barrier replace fire
execute as @s[tag=ija-a4-mined] run fill 0 60 0 0 60 0 barrier replace water
execute as @s[tag=ija-a4-mined] run fill 0 60 0 0 60 0 barrier replace flowing_water

tag @s[scores={ija-a4-counter=0}] add ija-a4-mined
scoreboard players add @s ija-a4-counter 0
execute as @s[tag=ija-a4-mined] run function infinite-block/increase-counter
execute as @s[scores={ija-a4-counter=..700}] run weather clear 5000
execute as @s[tag=ija-a4-mined] unless entity @s[scores={ija-a4-upgrade-seconds-left=1..}] run function generated/phase/manager
execute as @s[scores={ija-a4-cooldown=1..}] unless entity @s[tag=ija-a4-mined] unless entity @s[scores={ija-a4-upgrade-seconds-left=1..}] run function generated/phase/manager
execute if entity @s[scores={ija-a4-counter=1}] run titleraw @a actionbar {"rawtext":[{"text":"\u00A76Break\u00A7r the block below you!"}]}
execute as @s[tag=ija-a4-mined] run function generated/phase/show-floating-text
execute as @s[scores={ija-a4-cooldown=1}] run function effects/block-spawn

execute as @e[type=item,r=2] run function infinite-block/catch-item
execute as @s[tag=ija-a4-mined] as @a[x=-1,dx=2,y=59,dy=3,z=-1,dz=2] at @s run tp @s ~ 61.0 ~
execute as @a[x=-1,dx=2,y=58,dy=4,z=-1,dz=2] at @s if block ~ ~ ~ barrier run tp @s ~ ~0.3 ~

execute if block 0 60 0 barrier run scoreboard players add @s ija-a4-persistent-barrier-counter 1
execute unless block ~ ~ ~ barrier run scoreboard players set @s ija-a4-persistent-barrier-counter 0
execute as @s[scores={ija-a4-persistent-barrier-counter=20..}] run setblock 0 60 0 dirt
scoreboard players set @s[scores={ija-a4-persistent-barrier-counter=20..}] ija-a4-persistent-barrier-counter 0

scoreboard players add @s ija-a4-monster-party-countdown 0
scoreboard players remove @s[scores={ija-a4-monster-party-countdown=1..}] ija-a4-monster-party-countdown 1
execute as @s[tag=ija-a4-party] run function generated/monster-party/manager
execute as @e[scores={ija-a4-party-monster-time-left=1..}] run function monster-party/guard-manager

scoreboard players add @s ija-a4-cooldown 0
scoreboard players remove @s[scores={ija-a4-cooldown=1..}] ija-a4-cooldown 1
tag @s[tag=ija-a4-mined] remove ija-a4-mined





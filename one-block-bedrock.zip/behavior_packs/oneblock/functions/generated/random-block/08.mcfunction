# Copyright: OneBlock by IJAMinecraft
# https://ijaminecraft.com/map/oneblock/

scoreboard players random @s ija-a4-random-block-type 1 3741
execute if entity @s[scores={ija-a4-random-block-type=..290}] run setblock ~ ~ ~ grass_block
execute if entity @s[scores={ija-a4-random-block-type=291..335}] run setblock ~ ~ ~ clay
execute if entity @s[scores={ija-a4-random-block-type=336..350}] run setblock ~ ~ ~ podzol
execute if entity @s[scores={ija-a4-random-block-type=351..370}] run setblock ~ ~ ~ oak_log
execute if entity @s[scores={ija-a4-random-block-type=371..385}] run setblock ~ ~ ~ birch_log
execute if entity @s[scores={ija-a4-random-block-type=386..395}] run setblock ~ ~ ~ melon_block
execute if entity @s[scores={ija-a4-random-block-type=396..401}] run setblock ~ ~ ~ pumpkin
execute if entity @s[scores={ija-a4-random-block-type=402..590}] run setblock ~ ~ ~ stone
execute if entity @s[scores={ija-a4-random-block-type=591..655}] run setblock ~ ~ ~ gravel
execute if entity @s[scores={ija-a4-random-block-type=656..695}] run setblock ~ ~ ~ dirt
execute if entity @s[scores={ija-a4-random-block-type=696..725}] run setblock ~ ~ ~ dark_oak_log
execute if entity @s[scores={ija-a4-random-block-type=726..765}] run setblock ~ ~ ~ granite
execute if entity @s[scores={ija-a4-random-block-type=766..805}] run setblock ~ ~ ~ diorite
execute if entity @s[scores={ija-a4-random-block-type=806..845}] run setblock ~ ~ ~ andesite
execute if entity @s[scores={ija-a4-random-block-type=846..885}] run setblock ~ ~ ~ calcite
execute if entity @s[scores={ija-a4-random-block-type=886..955}] run setblock ~ ~ ~ coal_ore
execute if entity @s[scores={ija-a4-random-block-type=956..1039}] run setblock ~ ~ ~ iron_ore
execute if entity @s[scores={ija-a4-random-block-type=1040..1079}] run setblock ~ ~ ~ snow
execute if entity @s[scores={ija-a4-random-block-type=1080..1129}] run setblock ~ ~ ~ spruce_log
execute if entity @s[scores={ija-a4-random-block-type=1130..1154}] run setblock ~ ~ ~ packed_ice
execute if entity @s[scores={ija-a4-random-block-type=1155..1199}] run setblock ~ ~ ~ gold_ore
execute if entity @s[scores={ija-a4-random-block-type=1200..1214}] run setblock ~ ~ ~ amethyst_block
execute if entity @s[scores={ija-a4-random-block-type=1215..1294}] run setblock ~ ~ ~ prismarine
execute if entity @s[scores={ija-a4-random-block-type=1295..1404}] run setblock ~ ~ ~ sand
execute if entity @s[scores={ija-a4-random-block-type=1405..1444}] run setblock ~ ~ ~ prismarine_bricks
execute if entity @s[scores={ija-a4-random-block-type=1445..1474}] run setblock ~ ~ ~ dark_prismarine
execute if entity @s[scores={ija-a4-random-block-type=1475..1524}] run setblock ~ ~ ~ mud
execute if entity @s[scores={ija-a4-random-block-type=1525..1544}] run setblock ~ ~ ~ sea_lantern
execute if entity @s[scores={ija-a4-random-block-type=1545..1584}] run setblock ~ ~ ~ dripstone_block
execute if entity @s[scores={ija-a4-random-block-type=1585..1599}] run setblock ~ ~ ~ horn_coral_block
execute if entity @s[scores={ija-a4-random-block-type=1600..1614}] run setblock ~ ~ ~ brain_coral_block
execute if entity @s[scores={ija-a4-random-block-type=1615..1644}] run setblock ~ ~ ~ mangrove_log
execute if entity @s[scores={ija-a4-random-block-type=1645..1657}] run setblock ~ ~ ~ sponge
execute if entity @s[scores={ija-a4-random-block-type=1658..1669}] run setblock ~ ~ ~ fire_coral_block
execute if entity @s[scores={ija-a4-random-block-type=1670..1679}] run setblock ~ ~ ~ bubble_coral_block
execute if entity @s[scores={ija-a4-random-block-type=1680..1689}] run setblock ~ ~ ~ tube_coral_block
execute if entity @s[scores={ija-a4-random-block-type=1690..1703}] run setblock ~ ~ ~ diamond_ore
execute if entity @s[scores={ija-a4-random-block-type=1704..1873}] run setblock ~ ~ ~ cobblestone
execute if entity @s[scores={ija-a4-random-block-type=1874..1963}] run setblock ~ ~ ~ mossy_cobblestone
execute if entity @s[scores={ija-a4-random-block-type=1964..1988}] run setblock ~ ~ ~ moss_block
execute if entity @s[scores={ija-a4-random-block-type=1989..1993}] run setblock ~ ~ ~ pearlescent_froglight
execute if entity @s[scores={ija-a4-random-block-type=1994..1998}] run setblock ~ ~ ~ verdant_froglight
execute if entity @s[scores={ija-a4-random-block-type=1999..2003}] run setblock ~ ~ ~ ochre_froglight
execute if entity @s[scores={ija-a4-random-block-type=2004..2088}] run setblock ~ ~ ~ jungle_log
execute if entity @s[scores={ija-a4-random-block-type=2089..2146}] run setblock ~ ~ ~ redstone_ore
execute if entity @s[scores={ija-a4-random-block-type=2147..2241}] run setblock ~ ~ ~ red_sandstone
execute if entity @s[scores={ija-a4-random-block-type=2242..2331}] run setblock ~ ~ ~ red_sand
execute if entity @s[scores={ija-a4-random-block-type=2332..2381}] run setblock ~ ~ ~ sandstone
execute if entity @s[scores={ija-a4-random-block-type=2382..2384}] run setblock ~ ~ ~ suspicious_sand
execute if entity @s[scores={ija-a4-random-block-type=2385..2387}] run setblock ~ ~ ~ suspicious_sand
execute if entity @s[scores={ija-a4-random-block-type=2388..2390}] run setblock ~ ~ ~ suspicious_sand
execute if entity @s[scores={ija-a4-random-block-type=2391..2393}] run setblock ~ ~ ~ suspicious_sand
execute if entity @s[scores={ija-a4-random-block-type=2394..2453}] run setblock ~ ~ ~ hardened_clay
execute if entity @s[scores={ija-a4-random-block-type=2454..2493}] run setblock ~ ~ ~ acacia_log
execute if entity @s[scores={ija-a4-random-block-type=2494..2538}] run setblock ~ ~ ~ stained_hardened_clay ["color"="brown"]
execute if entity @s[scores={ija-a4-random-block-type=2539..2583}] run setblock ~ ~ ~ stained_hardened_clay ["color"="yellow"]
execute if entity @s[scores={ija-a4-random-block-type=2584..2628}] run setblock ~ ~ ~ stained_hardened_clay ["color"="orange"]
execute if entity @s[scores={ija-a4-random-block-type=2629..2673}] run setblock ~ ~ ~ stained_hardened_clay ["color"="red"]
execute if entity @s[scores={ija-a4-random-block-type=2674..2699}] run setblock ~ ~ ~ copper_ore
execute if entity @s[scores={ija-a4-random-block-type=2700..2729}] run setblock ~ ~ ~ emerald_ore
execute if entity @s[scores={ija-a4-random-block-type=2730..2756}] run setblock ~ ~ ~ lapis_ore
execute if entity @s[scores={ija-a4-random-block-type=2757..2836}] run setblock ~ ~ ~ netherrack
execute if entity @s[scores={ija-a4-random-block-type=2837..2886}] run setblock ~ ~ ~ blackstone
execute if entity @s[scores={ija-a4-random-block-type=2887..2926}] run setblock ~ ~ ~ soul_sand
execute if entity @s[scores={ija-a4-random-block-type=2927..2966}] run setblock ~ ~ ~ warped_nylium
execute if entity @s[scores={ija-a4-random-block-type=2967..3006}] run setblock ~ ~ ~ crimson_nylium
execute if entity @s[scores={ija-a4-random-block-type=3007..3046}] run setblock ~ ~ ~ basalt
execute if entity @s[scores={ija-a4-random-block-type=3047..3086}] run setblock ~ ~ ~ nether_brick
execute if entity @s[scores={ija-a4-random-block-type=3087..3126}] run setblock ~ ~ ~ red_nether_brick
execute if entity @s[scores={ija-a4-random-block-type=3127..3151}] run setblock ~ ~ ~ magma
execute if entity @s[scores={ija-a4-random-block-type=3152..3176}] run setblock ~ ~ ~ glowstone
execute if entity @s[scores={ija-a4-random-block-type=3177..3201}] run setblock ~ ~ ~ soul_soil
execute if entity @s[scores={ija-a4-random-block-type=3202..3226}] run setblock ~ ~ ~ shroomlight
execute if entity @s[scores={ija-a4-random-block-type=3227..3251}] run setblock ~ ~ ~ gilded_blackstone
execute if entity @s[scores={ija-a4-random-block-type=3252..3271}] run setblock ~ ~ ~ warped_wart_block
execute if entity @s[scores={ija-a4-random-block-type=3272..3291}] run setblock ~ ~ ~ nether_wart_block
execute if entity @s[scores={ija-a4-random-block-type=3292..3311}] run setblock ~ ~ ~ crimson_stem
execute if entity @s[scores={ija-a4-random-block-type=3312..3331}] run setblock ~ ~ ~ warped_stem
execute if entity @s[scores={ija-a4-random-block-type=3332..3343}] run setblock ~ ~ ~ obsidian
execute if entity @s[scores={ija-a4-random-block-type=3344..3346}] run setblock ~ ~ ~ crying_obsidian
execute if entity @s[scores={ija-a4-random-block-type=3347..3351}] run setblock ~ ~ ~ ancient_debris
execute if entity @s[scores={ija-a4-random-block-type=3352..3381}] run setblock ~ ~ ~ quartz_ore
execute if entity @s[scores={ija-a4-random-block-type=3382..3406}] run setblock ~ ~ ~ nether_gold_ore
execute if entity @s[scores={ija-a4-random-block-type=3407..3641}] run setblock ~ ~ ~ quartz_block
execute if entity @s[scores={ija-a4-random-block-type=3642..3716}] run setblock ~ ~ ~ cherry_log
execute if entity @s[scores={ija-a4-random-block-type=3717..3731}] run setblock ~ ~ ~ honeycomb_block
execute if entity @s[scores={ija-a4-random-block-type=3732..3735}] run setblock ~ ~ ~ honey_block
execute if entity @s[scores={ija-a4-random-block-type=3736..3739}] run setblock ~ ~ ~ slime
execute if entity @s[scores={ija-a4-random-block-type=3740}] run setblock ~ ~ ~ bee_nest
execute run setblock ~ ~ ~ beehive

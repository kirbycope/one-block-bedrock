playsound random.pop @s

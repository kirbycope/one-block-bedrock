tag @s add ija-a4-joined
spawnpoint @s 0 61 0
setworldspawn 0 61 0
tp @s 0.5 61.3 0.5 90 50
scoreboard players add @s ija-a4-usermined 0
scoreboard players add @s ija-a4-alldeath 0
scoreboard players add @s ija-a4-tempdeath 0
scoreboard players add @s ija-a4-isdead 0
